import javax.swing.*;

public class MainMenu {
    private static IntegerStack integerData;
    private static OperationStack operationData;
    private static StatementStack statementData;
    private static IterationStack iterationData;
    private static int count = 1;
    private static final String Line_Dash = "-------------------------------------------------------";
    private static String statement;

    public static void main(String[] args) throws Exception {
        statementData = new ProjectStack();
        iterationData = new ProjectStack();
        integerData = new ProjectStack();
        operationData = new ProjectStack();
        showmenu();
    }

    private static void showmenu() throws Exception {
        String prompt = String.format(
                "%s\n %30s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s",
                Line_Dash,
                "Main Menu",
                Line_Dash,
                "1) Enter the entire statement",
                "2) Enter one by one",
                Line_Dash,
                "3) Solution of the entire statement",
                "4) Solution of one by one method",
                "5) Check the summary",
                Line_Dash,
                "6) Clear Statement Data",
                "7) Clear Iteration Data",
                "8) Exit Program"
        );
        String selectedchoice = JOptionPane.showInputDialog(null, prompt, "Input", JOptionPane.QUESTION_MESSAGE);
        try {
            int option = Integer.parseInt(selectedchoice);
            switch (option) {
                case 1 -> enterStatement();
                case 2 -> enterIteration();
                case 3 -> getStatementSolution();
                case 4 -> getIterationSolution();
                case 5 -> checkSummary();
                case 6 -> clearStatement();
                case 7 -> clearIteration();
                case 8 -> System.exit(0);
                default -> {
                    JOptionPane.showMessageDialog(null, "Operation Not Found.", "Message", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            showmenu();
        }
    }

    public static void enterStatement() throws Exception {
        statement = JOptionPane.showInputDialog(null, "Input your Statement :");
        boolean checkStatement = balancingSymbol(statement);
        if (!checkStatement) {
            JOptionPane.showMessageDialog(null, "Please type correct equation.", "Message", JOptionPane.INFORMATION_MESSAGE);
        }
        showmenu();
    }

    private static void enterIteration() throws Exception {
        if (iterationData.empty()) {
            int number1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Input your First Number :"));
            iterationData.push(number1);
        }
        String operation = JOptionPane.showInputDialog(null, "Input your Operation :");
        char op = operation.charAt(0);
        if (op != '+' && op != '-' && op != '*' && op != '/' && op != '^') {
            JOptionPane.showMessageDialog(null, "Please type correct operation.", "Message", JOptionPane.INFORMATION_MESSAGE);
            iterationData.clear();
            count = 1;
            showmenu();
        } else {
            iterationData.push(op);
            int number2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Input your Second Number :"));
            iterationData.push(number2);
            showmenu();
        }
    }
    //      1 + ( 1 + 1 ) + 1
    private static void getStatementSolution() throws Exception {
        char[] charStatement = statement.toCharArray();

        for (int i = 0 ; i < statement.length() ; i++) {
            if (charStatement[i] >= '0' && charStatement[i] <= '9') {
                StringBuffer stbf = new StringBuffer();
                while (i < charStatement.length && charStatement[i] >= '0' && charStatement[i] <= '9') {
                    stbf.append(charStatement[i++]);
                }
                integerData.push(Integer.parseInt(stbf.toString()));
                i--;
            } else if (charStatement[i] == '(') {
                operationData.push(charStatement[i]);
            } else if (charStatement[i] == '+' || charStatement[i] == '-' || charStatement[i] == '*' || charStatement[i] == '/') {
                while (!operationData.empty() && checkPrecedence(charStatement[i], (Character) operationData.top())) {
                    integerData.push(calculate((Character) operationData.pop(), (Integer) integerData.pop(), (Integer) integerData.pop()));
                }
                operationData.push(charStatement[i]);
            } else if (charStatement[i] == ')') {
                while ((Character) operationData.top() != '(') {
                    integerData.push(calculate((Character) operationData.pop(), (Integer) integerData.pop(), (Integer) integerData.pop()));
                    if ((Character) operationData.pop() == '(') {
                        break;
                    }
                }
            }
        }
        while (!operationData.empty()) {
            integerData.push(calculate((Character) operationData.pop(), (Integer) integerData.pop(), (Integer) integerData.pop()));
        }
        JOptionPane.showMessageDialog(null , integerData.pop());
        showmenu();
    }
    public static boolean checkPrecedence(char op1, char op2) {
        if (op2 == '(' || op2 == ')') {
            return false;
        }
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-')) {
            return false;
        } else {
            return true;
        }
    }
    public static int calculate(char op, int b, int a) {
        switch (op) {
            case '+':   return a + b;
            case '-':   return a - b;
            case '*':   return a * b;
            case '/':   if (b == 0) {
                            throw new UnsupportedOperationException("Cannot divide by zero");
                        }
                        return a / b;
        }
        return 0;
    }

    private static void getIterationSolution() throws Exception {
//        int sum = (int) iterationData.pop();
//        while (!iterationData.empty()) {
//            char b = (char) iterationData.pop();
//            int c = (int) iterationData.pop();
//            switch (b) {
//                case ('+') -> {
//                    JOptionPane.showMessageDialog(null , "\nMethod " + count + " : " + sum + " " + b + " " + c + " = " + Math.addExact(sum , c));
//                    sum += c;
//                    break;
//                }
//                case ('-') -> {
//                    JOptionPane.showMessageDialog(null , "\nMethod " + count + " : " + sum + " " + b + " "  + c + " = " + Math.subtractExact(sum , c));
//                    sum -= c;
//                    break;
//                }
//                case ('*') -> {
//                    JOptionPane.showMessageDialog(null , "\nMethod " + count + " : " + sum + " " + b + " " + c + " = " + Math.multiplyExact(sum , c));
//                    sum *= c;
//                    break;
//                }
//                case ('/') -> {
//                    JOptionPane.showMessageDialog(null , "\nMethod " + count + " : " + sum + " " + b + " " + c + " = " + Math.divideExact(sum , c));
//                    sum /= c;
//                    break;
//                }
//                case ('^') -> {
//                    JOptionPane.showMessageDialog(null , "\nMethod " + count + " : " + sum + " " + b + " " + c + " = " + Math.pow(sum , c));
//                    sum = (int) Math.pow(sum , c);
//                    break;
//                }
//            }
//            count++;
//        }
        showmenu();
    }
    private static boolean balancingSymbol(String a) throws Exception {
        for (int i = 0; i < a.length(); i++) {
            char c = a.charAt(i);
            if (c != ')') {
                statementData.push(c);
            } else {
                if (statementData.empty()) {
                    return false;
                }
                char check;
                for (int j = a.indexOf(c); j > 0; j--) {
                    check = (char) statementData.pop();
                    if (check == '(') {
                        return true;
                    } else if (statementData.empty()) {
                        return false;
                    }
                }
            }
        }
        return statementData.empty();
    }
//    private static boolean balancingSymbol(String a) throws Exception {
//        for (int i = 0; i < a.length(); i++) {
//            char c = a.charAt(i);
//            if (c != ')' && c != '}' && c != ']') {
//                statementData.push(c);
//            } else {
//                if (statementData.empty()) {
//                    return false;
//                }
//                char check;
//                switch (c) {
//                    case (')') -> {
//                        for (int j = a.indexOf(c); j > 0; j--) {
//                            check = (char) statementData.pop();
//                            if (check == '{' || check == '[') {
//                                return false;
//                            } else if (check == '(') {
//                                return true;
//                            } else if (statementData.empty()) {
//                                return false;
//                            }
//                        }
//                    }
//                    case (']') -> {
//                        for (int j = a.indexOf(c); j > 0; j--) {
//                            check = (char) statementData.pop();
//                            if (check == '{' || check == '(') {
//                                return false;
//                            } else if (check == '[') {
//                                return true;
//                            } else if (statementData.empty()) {
//                                return false;
//                            }
//                        }
//                    }
//                    case ('}') -> {
//                        for (int j = a.indexOf(c); j > 0; j--) {
//                            check = (char) statementData.pop();
//                            if (check == '(' || check == '[') {
//                                return false;
//                            } else if (check == '{') {
//                                return true;
//                            } else if (statementData.empty()) {
//                                return false;
//                            }
//                        }
//                    }
//                }
//
//            }
//        }
//        return statementData.empty();
//    }
    private static void clearStatement() throws Exception {
        statementData.clear();
        showmenu();
    }

    private static void clearIteration() throws Exception {
        iterationData.clear();
        showmenu();
    }

    private static void checkSummary() {
    }
}