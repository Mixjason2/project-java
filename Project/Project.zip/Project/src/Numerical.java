public class Numerical {
    public static IntegerStack integerData;
    public static OperationStack operationData;
    public static int evaluate(String expression) throws Exception {
        IntegerStack integerData = new ProjectStack();
        operationData = new ProjectStack();
        char[] tokens = expression.toCharArray();

        for (int i = 0 ; i < tokens.length ; i++){
            if (tokens[i] >= '0' && tokens[i] <= '9'){
                StringBuffer buffered = new StringBuffer();
                while (i < tokens.length && tokens[i] >= '0' && tokens[i] <= '9'){
                    buffered.append(tokens[i++]);
                    integerData.push(Integer.parseInt(buffered.toString()));
                }
                i--;
            } else if (tokens[i] == '(') {
                operationData.push(tokens[i]);
            } else if (tokens[i] == ')') {
                while ((Character) operationData.top() != '('){
                    integerData.push(operate((Character) operationData.pop(), (Integer) integerData.pop(), (Integer) integerData.pop()));
                    operationData.pop();
                }
            } else if (tokens[i] == '+' || tokens[i] == '-' || tokens[i] == '*' || tokens[i] == '/' || tokens[i] == '^') {
                while (!operationData.empty() && checkPrecedence(tokens[i] , (Character) operationData.top())){
                    integerData.push(operate((Character) operationData.pop(), (Integer) integerData.pop(), (Integer) integerData.pop()));
                }
                operationData.push(tokens[i]);
            }
        }
        while (!operationData.empty()){
            integerData.push(operate((Character) operationData.pop(), (Integer) integerData.pop(), (Integer) integerData.pop()));
        }
        return (int) integerData.pop();
    }
    public static boolean checkPrecedence(char op1 , char op2){
        if (op2 == '(' || op2 == ')'){
            return false;
        }
        if (op1 =='*' || op1 =='/' && op2 =='+' || op2 =='-'){
            return false;
        } else {
            return true;
        }
    }
    public static int operate(char op , int num1 , int num2){
        switch (op) {
                case ('+') -> {
                    return num1 + num2;
                }
                case ('-') -> {
                    return num1 - num2;
                }
                case ('*') -> {
                    return num1 * num2;
                }
                case ('/') -> {
                    if (num2 == 0) throw new UnsupportedOperationException("Cannot divide by zero");
                    return num1 / num2;
                }
                case ('^') -> {
                    return num1 ^ num2;
                }
            }
        return 0;
    }
}